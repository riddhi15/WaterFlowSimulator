import './App.css';
import { HomePage } from './components/HomePage';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <HomePage></HomePage>
      </header>
    </div>
  );
}

export default App;
